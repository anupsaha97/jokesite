<?php

$hostname = "localhost";

 // example  "localhost"  for hosting in your own computer or mysql hostname according to your hosting service provider if you are not hosting in localhos and using a hosting service.


$username = "mysql database username";

$password = "mysql password";

$database = "database name";

$port = 3306 ;  // mysql portnumber 
// enter your mysql port number. enter 3306 if hosting in own local pc and if mysql port number is not changed.
// enter the port number provided by hosting service if you are hosting the site in any hosting service provider most of the times port number is 3306 . 

?>
