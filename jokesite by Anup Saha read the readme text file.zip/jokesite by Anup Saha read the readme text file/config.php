<?php

$hostname = "your mysql host name";

 // example  "localhost"  for hosting in your own computer or mysql hostname according to your hosting service provider if you are not hosting in localhos and using a hosting service.


$username = "your mysql username";

$password = "your mysql password";

$database = "your mysql database name";

$port = your mysql port number ; 

// enter your mysql port number without this " " quotes.enter 3306 if hostin in own local pc and if mysql port number is not changed. enter the port number provided by hosting service if you are hosting the site in any hosting service provider most of the times port number is 3306 . 

?>
