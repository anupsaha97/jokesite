<?php
include("config.php");

$con = mysqli_connect($hostname,$username,$password,$database,$port);

// Check connection
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}


$sql = "INSERT INTO jokes(POSTER_NAME,JOKE_TITLE,JOKE_CATEGORY,JOKE_TEXT) VALUES('$_POST[name]','$_POST[joketitle]','$_POST[jokecategory]','$_POST[joketext]')";



if (mysqli_query($con,$sql)) {
          echo "joke posted";

}
else {
  printf("error: %s\n", mysqli_error($con));
}

mysqli_close($con);
echo "<script type=text/javascript >
          alert('joke posted');
          window.history.back();
      </script>";

?>
