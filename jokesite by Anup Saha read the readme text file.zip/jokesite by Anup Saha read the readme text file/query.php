<?php
include("config.php");
$response="";
$result;
$numjokes=0;
$numofjokestofetch=10;
$category="Husband Wife";
$sql= " ";
$con;
$row;

if (array_key_exists('numjokes', $_POST) && array_key_exists('numofjokestofetch', $_POST) && array_key_exists('category',$_POST))
{
  $numjokes=$_POST['numjokes'];
  $numofjokestofetch=$_POST['numofjokestofetch'];
  $category=$_POST['category'];
}


if (!strcmp($category,"Latest"))
{
    $sql= "SELECT  *  FROM  jokes  ORDER  BY  S_NO  DESC  LIMIT  " . $numofjokestofetch . "  OFFSET  " . $numjokes ;
//    echo $sql;
}

else if (!strcmp($category,"Most Laughs"))
{
    $sql= "SELECT  *  FROM  jokes  ORDER  BY  HAHA_TIMES  DESC  LIMIT  " . $numofjokestofetch . "  OFFSET  " . $numjokes ;
//    echo $sql;
}

else
{
  $sql =  "SELECT  *  FROM  jokes  WHERE  JOKE_CATEGORY='".$category."'  ORDER  BY   S_NO  DESC  LIMIT  " . $numofjokestofetch . "  OFFSET  " . $numjokes ;
//  echo $sql;
}

$con = mysqli_connect($hostname,$username,$password,$database,$port);
$result=mysqli_query($con,$sql);
if ($result)
{
//          echo "<br/>query ok<br/>";

}
else {
printf("<br/>error: %s<br/>\n", mysqli_error($con));
mysqli_close($con);
exit;
}

while ($row = mysqli_fetch_assoc($result))
{

      $response = $response."<br/><div class='card' >
        <div class='card-header'>Posted By - <h6> ".$row['POSTER_NAME']."</h6>&nbsp&nbsp&nbsp at &nbsp;&nbsp; <h6>".$row['POST_DATE']."</h6>
      </div>
      <div class='card-body'>
        <h5 class='card-title'>".$row['JOKE_TITLE']."</h5>
        <p class='card-text'><pre>".$row['JOKE_TEXT']."</pre></p>
        <span><span id='".$row['S_NO']."'>".$row['HAHA_TIMES']."</span><img src='images/emoji.png' width=37px height=37px onclick='haha(".$row['S_NO'].")'></span>
      </div>
    </div>";
}

//echo " <br/>ajax response";
echo $response;
mysqli_close($con);


?>
