<?php

include("config.php");
$response;
$result;
$row;
$S_NO =$_POST['id'];
$sql=" ";
$con;


$sql = "UPDATE jokes SET HAHA_TIMES = HAHA_TIMES + 1 WHERE S_NO =".$S_NO.";" ;
$sql = $sql."SELECT HAHA_TIMES FROM jokes WHERE S_NO = ".$S_NO.";" ;
// echo $sql;
$con = mysqli_connect($hostname,$username,$password,$database,$port);

if (mysqli_multi_query($con,$sql))
{
      do
      {

         if ($result=mysqli_store_result($con))
         {
           

            while ($row=mysqli_fetch_row($result))
            {
                $response = $row[0];
            }
            mysqli_free_result($result);
         }
      }while (mysqli_more_results($con)&&mysqli_next_result($con));
   }

//$response = $row['HAHA_TIMES'];


//echo " <br/>ajax response";
echo $response;
mysqli_close($con);

 ?>
