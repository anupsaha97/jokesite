var numjokes= 0;
var numofjokestofetch= 10;
var category = "Most Laughs";
var request="blank";
var id=" ";
var addjokes=0;

function docloaded(){
  //alert("loaded");
  //createrequest();
  if(!addjokes)loadjokes();
}
//function createrequest(){
//  request= numjokes +","+ numofjokestofetch +","+ category + ",";
//}
function changecategory(cat)
{
    addjokes=0;
    category=cat;
    numjokes=0;
    document.getElementById("content").innerHTML="";
    if(!addjokes)loadjokes();
}

function loadjokes()
{
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
       document.getElementById("content").innerHTML += this.responseText;
       numjokes += numofjokestofetch;
       //alert("response");
      }
    };
    xhttp.open("POST", "query.php", true);
    xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    request = "numjokes="+numjokes+"&numofjokestofetch="+numofjokestofetch+"&category="+category;
    xhttp.send(request);
    //alert("sent");
}



$(window).scroll(function() {
   if($(window).scrollTop() + $(window).height() == $(document).height())
    {

      // code for when document reached to bottom

        //alert("bottom!");
        if(!addjokes)loadjokes();


   }
});


function addjoke()
{
  addjokes=1;
  category = "none";
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
       document.getElementById('content').innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", "add jokes.html", true);
    xhttp.send();
}

function about()
{
  addjokes=1;
  category = "none";
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
       document.getElementById('content').innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", "about.html", true);
    xhttp.send();
}

function contact()
{
  addjokes=1;
  category = "none";
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {
       document.getElementById('content').innerHTML = this.responseText;
      }
    };
    xhttp.open("GET", "contact.html", true);
    xhttp.send();
}


function haha(S_NO)
{
    id=S_NO.toString();
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
         document.getElementById(id).innerHTML = this.responseText;
        // alert("response");
        }
      };
      xhttp.open("POST", "haha.php", true);
      xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      request = "id="+id;
      xhttp.send(request);
      //alert("sent");

}

var searchstring;
function search()
{
  searchstring= document.getElementById("searchbar").value;
  if(!addjokes)
  {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function()
  {
      if (this.readyState == 4 && this.status == 200)
      {

       document.getElementById('content').innerHTML = this.responseText;
      // alert("response");
      }
    };
  xhttp.open("POST", "search.php", true);
  xhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
  request="searchstring="+searchstring;
  xhttp.send(request);


}
}
/*
function toggler()
{
  if (togglestate)
  {
    togglestate=0;
    document.getElementById("sidebar").style.position = "fixed";
    alert(togglestate);
  }
  else
  {
      togglestate=1;
      document.getElementById("sidebar").style.position = "absolute";
      alert(togglestate);
  }
}
*/
